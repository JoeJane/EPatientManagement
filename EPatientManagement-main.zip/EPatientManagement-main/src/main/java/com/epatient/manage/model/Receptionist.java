package com.epatient.manage.model;

import javax.persistence.Entity;
import javax.persistence.Table;

@Entity
@Table(name = "receptionist")
public class Receptionist extends User{
}
