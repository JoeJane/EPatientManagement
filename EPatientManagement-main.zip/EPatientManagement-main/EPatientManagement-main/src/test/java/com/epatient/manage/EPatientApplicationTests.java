package com.epatient.manage;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EPatientApplicationTests {

	@Test
	void contextLoads() {
	}

}
