package com.epatient.manage.service;

public interface PatientService {
}
