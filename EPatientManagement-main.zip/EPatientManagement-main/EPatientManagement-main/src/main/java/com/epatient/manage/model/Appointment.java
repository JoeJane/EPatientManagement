package com.epatient.manage.model;

import java.time.LocalDateTime;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import org.hibernate.annotations.CreationTimestamp;

@Entity
@Table(name = "appointment")
public class Appointment {
	@Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private Integer id;
	
	@Column(name="patient_id")
	Integer patientId;
	
	@Column(name="recetionist_id")
    Integer receptionistId;
	 
    @CreationTimestamp
    @Column(name = "created_at", updatable = false)
    private LocalDateTime createdAt;
    
    @Column(name = "bookingTime")
    private LocalDateTime bookingTime;

    
    
	public Appointment() {
		super();
	}



	public Appointment(Integer patientId, Integer receptionistId, LocalDateTime createdAt, LocalDateTime bookingTime) {
		super();
		this.patientId = patientId;
		this.receptionistId = receptionistId;
		this.createdAt = createdAt;
		this.bookingTime = bookingTime;
	}



	public Integer getId() {
		return id;
	}



	public void setId(Integer id) {
		this.id = id;
	}



	public Integer getPatientId() {
		return patientId;
	}



	public void setPatientId(Integer patientId) {
		this.patientId = patientId;
	}



	public Integer getReceptionistId() {
		return receptionistId;
	}



	public void setReceptionistId(Integer receptionistId) {
		this.receptionistId = receptionistId;
	}



	public LocalDateTime getCreatedAt() {
		return createdAt;
	}



	public void setCreatedAt(LocalDateTime createdAt) {
		this.createdAt = createdAt;
	}



	public LocalDateTime getBookingTime() {
		return bookingTime;
	}



	public void setBookingTime(LocalDateTime bookingTime) {
		this.bookingTime = bookingTime;
	}

	
}
