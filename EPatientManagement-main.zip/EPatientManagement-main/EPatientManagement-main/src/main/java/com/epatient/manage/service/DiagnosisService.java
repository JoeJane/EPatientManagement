package com.epatient.manage.service;

import com.epatient.manage.model.Diagnosis;

public interface DiagnosisService {
    public Diagnosis findById(Integer id);
}
