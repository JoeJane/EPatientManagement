package com.epatient.manage.controller;

import java.io.IOException;
import java.security.Principal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.Period;
import java.time.format.DateTimeFormatter;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;
import java.util.stream.Collectors;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.epatient.manage.model.Appointment;
import com.epatient.manage.model.Patient;
import com.epatient.manage.model.Role;
import com.epatient.manage.model.SearchTerm;
import com.epatient.manage.model.User;
import com.epatient.manage.repository.AppointmentRepository;
import com.epatient.manage.service.PatientService;
import com.epatient.manage.service.UserService;
import com.epatient.manage.util.Converter;

/**
 * This class handles all the Receptionist related functionalities
 * Author: Mudiaga(Raphael)Otojareri (Done) Chen (Done) Shaqayeq (pending)
 * Created on : 12/10/2022
 */
@Controller
public class ReceptionistController {
	@Autowired
	UserService userService;
	@Autowired
	PatientService patientService;
	@Autowired
	AppointmentRepository appointmentRepository;

	@GetMapping("/receptionist/home")
	public String receptionistHome(Model model, Principal principal) {
		List<User> users = userService.findByRole(Role.PATIENT);
		LocalDate curDate = LocalDate.now();
		users.forEach( user -> {
			user.setAge(Period.between(user.getDateOfBirth(), curDate).getYears());
		});
		
		User currentUser  = (User)((UsernamePasswordAuthenticationToken) principal).getPrincipal();

		model.addAttribute("searchterm", new SearchTerm());
		model.addAttribute("bulkAction", new SearchTerm());
		model.addAttribute("users", users);
		model.addAttribute("roles", getRoles());
		model.addAttribute("message", "Welcome " + currentUser.getFullName());
		
		return "/receptionist/receptionistHome"; // shaqayeq is somehow missing... (manage patient and booking)
	}
	
	@GetMapping("receptionist/add")
	public String addPatient(Model model) {
		model.addAttribute("userForm", new User());
		model.addAttribute("patient", initializePatient());
		model.addAttribute("countries", getCountries());
		return "/receptionist/registerForm";
	}
	
	@PostMapping("receptionist/save")
	public String addPatient(Model model, @ModelAttribute("userForm") @Valid User user, BindingResult bindingResult,
			final RedirectAttributes redirectAttributes) {
		if(user.getRole() == Role.PATIENT) {
			if(user.getBloodGroup() == null){
				bindingResult.rejectValue("bloodGroup", "required.bloodGroup");
			}
			if(user.getEmergencyFirstName() == null){
				bindingResult.rejectValue("emergencyFirstName", "required.emergencyFirstName");
			}
			if(user.getEmergencyLastName() == null){
				bindingResult.rejectValue("emergencyLastName", "required.emergencyLastName");
			}
			if(user.getEmergencyEmail() == null){
				bindingResult.rejectValue("emergencyEmail", "required.emergencyEmail");
			}
			if(user.getEmergencyPhone() == null){
				bindingResult.rejectValue("emergencyPhone", "required.emergencyPhone");
			}
		}
		if(user.getUserId()==null && userService.findUserByUsername(user.getUsername()).isPresent()){
			bindingResult.rejectValue("username", "Duplicate.userForm.username");
		}


		if (bindingResult.hasErrors()) {
			System.out.println("Not able to create user");
			return "/receptionist/createpatient";
		}
		redirectAttributes.addFlashAttribute("alert", "success");
		if (user.isNew()) {
			redirectAttributes.addFlashAttribute("msg", "User added successfully!");
		} else {
			redirectAttributes.addFlashAttribute("msg", "User updated successfully!");
		}

		User newUser = Converter.convert(user);
		userService.saveOrUpdate(newUser);

		return "redirect:/receptionist/view" + newUser.getUserId(); //For now because Chen has not finished with the recptionist view yet
	}
	
	@GetMapping("receptionist/view/{id}")
	public String viewPatient(@PathVariable("id") Integer id, Model model) {
		User user = userService.findById(id).orElse(new User());
		model.addAttribute("userForm", user);
		return "/receptionist/viewForm";
	}
	
	@GetMapping("viewAppointment/{userId}")
	public String viewAppointment(@PathVariable("userId") Integer id, Model model, Principal principal) {
		User patient = userService.findById(id).orElse(new User());
		User receptionist  = (User)((UsernamePasswordAuthenticationToken) principal).getPrincipal();
		List<Appointment> appointmentList = appointmentRepository.findAll();
		model.addAttribute("appointmentList", appointmentList);
		return "/receptionist/viewAppointment";
	}
	
	@GetMapping("bookAppointment/{userId}")
	public String getBookAppointment(@PathVariable("userId") Integer id, Model model, Principal principal) {
		model.addAttribute("patientId", id);
		return "/receptionist/bookAppointment";
	}
	
	@PostMapping("bookAppointment/{userId}")
	public String bookAppointment(@PathVariable("userId") Integer id, Model model, Principal principal, HttpServletRequest request) {
		User patient = userService.findById(id).orElse(new User());
		User receptionist  = (User)((UsernamePasswordAuthenticationToken) principal).getPrincipal();
		String bookingTimeString = request.getParameter("appointmentDate");
		
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
		LocalDateTime bookingTime = LocalDate.parse(bookingTimeString, formatter).atStartOfDay();
		Appointment appointment = new Appointment(patient.getUserId(), receptionist.getUserId(), LocalDateTime.now(), bookingTime);
		appointmentRepository.save(appointment);
		return "/receptionist/viewAppointment";
	}	
	
	@GetMapping("/receptionist/createpatient")
	public void createPatient(Model model) throws IOException, Exception{
		model.addAttribute("userForm", new User());
		model.addAttribute("patient", initializePatient());
		
	}
	
	@ModelAttribute("patients")
	public List<User> initializePatient(){
		return userService.findByRole(Role.PATIENT);
	}
	
	private static Map<Role, String> getRoles(){
		Map<Role, String> roles = Arrays.stream(Role.values()).collect(Collectors.toMap(e->e, e->e.getValue(), (oldValue, newValue) -> oldValue, TreeMap::new));
		roles.remove(Role.ADMIN);
		return roles;
	}
	
	private static Map<String, String> getCountries(){
		Map<String, String> countries = new TreeMap<>();
		countries.put("CA", "Canada");
		countries.put("US", "America");

		return countries;
	}
}
