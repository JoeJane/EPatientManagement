package com.epatient.manage.service;

import org.springframework.stereotype.Service;

@Service
public class PatientServiceImpl implements PatientService{
}
